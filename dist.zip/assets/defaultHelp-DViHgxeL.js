import{c as e,n as t,s as n}from"./fontConfig-DoGy8I__.js";var r=`<h2>功能介绍</h2>
<ul>
  <li>查看服务器状态</li>
  <li>查看绑定玩家信息</li>
  <li>阅读帮助说明</li>
</ul>

<h2>使用说明</h2>
<ul>
  <li>发送“服务器状态”查看当前在线信息</li>
  <li>发送“玩家信息”查看你的个人数据</li>
</ul>`,i={sections:[{title:`功能介绍`,items:[`查看服务器状态`,`查看绑定玩家信息`,`阅读帮助说明`]},{title:`使用说明`,items:[`发送“服务器状态”查看当前在线信息`,`发送“玩家信息”查看你的个人数据`]}]},a={mode:`image`,imageUrl:`https://t.mwm.moe/mp`,solidColor:`#1a2332`,gradient:`linear-gradient(135deg, #1f2a44, #243b55, #2c5364)`},o={title:`帮助说明`,emptyText:`暂无帮助内容`,background:a,font:t,customFonts:[],html:r,sections:i.sections};function s(e){if(!e||typeof e!=`object`)return a;let t=e;return{mode:t.mode===`solid`||t.mode===`gradient`||t.mode===`image`?t.mode:a.mode,imageUrl:typeof t.imageUrl==`string`&&t.imageUrl.trim()?t.imageUrl.trim():a.imageUrl,solidColor:typeof t.solidColor==`string`&&t.solidColor.trim()?t.solidColor.trim():a.solidColor,gradient:typeof t.gradient==`string`&&t.gradient.trim()?t.gradient.trim():a.gradient}}function c(e){if(!e||typeof e!=`object`)return null;let t=e.sections;if(!Array.isArray(t)||t.length===0)return null;let n=t.filter(e=>!!e&&typeof e.title==`string`&&Array.isArray(e.items)).map(e=>({title:e.title.trim(),items:e.items.map(e=>String(e).trim()).filter(Boolean)})).filter(e=>e.title&&e.items.length>0);return n.length===0?null:{sections:n}}function l(t){let a=c(t)?.sections??i.sections;if(!t||typeof t!=`object`)return{...o,sections:a};let l=t;return{title:typeof l.title==`string`&&l.title.trim()?l.title.trim():o.title,emptyText:typeof l.emptyText==`string`&&l.emptyText.trim()?l.emptyText.trim():o.emptyText,background:s(l.background),font:e(l.font),customFonts:n(l.customFonts),html:typeof l.html==`string`&&l.html.trim()?l.html:r,sections:a}}export{l as i,r as n,o as r,a as t};